//aqui viene la lista de amigos, agregar amigo
// la última actividad
//y la opción de enviar un reto
//ESTO TE TOCA YAHIRRRR

import 'package:flutter/material.dart';

class Amigos extends StatefulWidget {
  const Amigos({super.key});

  @override
  State<Amigos> createState() => _AmigosState();
}

class _AmigosState extends State<Amigos> {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text("AMIGOS Y RETOS"),);
  }
}
